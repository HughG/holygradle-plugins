#pragma once

class Oracle
{
public:
    Oracle(void);
    ~Oracle(void);

    int Prediction();
};

