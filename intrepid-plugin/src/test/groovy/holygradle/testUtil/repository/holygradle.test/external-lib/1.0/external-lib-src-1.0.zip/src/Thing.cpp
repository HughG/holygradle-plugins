#include "stdafx.h"
#include "Thing.h"

Thing::Thing(void)
{
}

Thing::~Thing(void)
{
}

int Thing::Method() {
    return 5;
}