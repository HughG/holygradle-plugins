#pragma once

class Thing
{
public:
    Thing(void);
    ~Thing(void);

    int Method();
};

