#include "stdafx.h"
#include "Oracle.h"
#include "Thing.h"

Oracle::Oracle(void)
{
}


Oracle::~Oracle(void)
{
}

int Oracle::Prediction() {
    Thing thing;
    return thing.Method() * 2;
}